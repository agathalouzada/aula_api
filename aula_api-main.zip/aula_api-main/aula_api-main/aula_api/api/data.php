<?php

return [
    [
        'nome' => 'Anderson',
        'email' => 'anderson@gmail.com'
    ],
    [
        'nome' => 'Cíntia',
        'email' => 'cintia@gmail.com'
    ],
    [
        'nome' => 'Ana Laura',
        'email' => 'analaura@gmail.com'
    ],
    [
        'nome' => 'Kaike',
        'email' => 'kaike@gmail.com'
    ],
    [
        'nome' => 'Breno',
        'email' => 'breno@gmail.com'
    ],
    [
        'nome' => 'Deniel',
        'email' => 'deniel@gmail.com'
    ],
    [
        'nome' => 'Ana Cordeiro',
        'email' => 'anacordeiro@gmail.com'
    ],
    [
        'nome' => 'Vitor',
        'email' => 'vitor@gmail.com'
    ],
    [
        'nome' => 'Kelly',
        'email' => 'kelly@gmail.com'
    ],
    [
        'nome' => 'Marcos Pedro',
        'email' => 'marcospedro@gmail.com'
    ],
        
];