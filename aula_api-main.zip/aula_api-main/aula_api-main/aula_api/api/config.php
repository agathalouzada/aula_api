<?php
    // AQUI SERÁ NOSSA API
    define('API_IS_ACTIVE',true);
    define('API_VERSION','1.0.0');
    
?>